#include "stm32f4xx.h"
#include <stdint.h>

static void uart_init(void);
static void uart_tx(char c);
static void uart_str(const char *s);
static void uart_num(uint16_t n);

static void adc_init(void);
static uint16_t adc_read(void);

/* USART2 Setup: 115200 Baud, 8N1, PA2 (TX) & PA3 (RX) */
static void uart_init(void)
{
    /* Enable GPIOA and USART2 clocks */
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;
    RCC->APB1ENR |= RCC_APB1ENR_USART2EN;

    /* PA2 -> AF7 (USART2_TX) */
    GPIOA->MODER &= ~(3U << (2 * 2));
    GPIOA->MODER |=  (2U << (2 * 2));

    /* PA3 -> AF7 (USART2_RX) */
    GPIOA->MODER &= ~(3U << (2 * 3));
    GPIOA->MODER |=  (2U << (2 * 3));

    /* Map Alternate Function 7 to PA2 and PA3 */
    GPIOA->AFR[0] &= ~((0xFU << (4 * 2)) | (0xFU << (4 * 3)));
    GPIOA->AFR[0] |=  ((7U << (4 * 2))   | (7U << (4 * 3)));

    /* 16 MHz HSI -> BRR = 0x008B for 115200 Baud */
    USART2->BRR = 0x008BU;
    USART2->CR1 = USART_CR1_TE | USART_CR1_RE | USART_CR1_UE;
}

static void uart_tx(char c)
{
    while (!(USART2->SR & USART_SR_TXE));
    USART2->DR = (uint8_t)c;
}

static void uart_str(const char *s)
{
    while (*s)
    {
        uart_tx(*s++);
    }
}

static void uart_num(uint16_t n)
{
    char b[6];
    int i = 0;

    if (n == 0)
    {
        uart_tx('0');
        return;
    }

    while (n > 0)
    {
        b[i++] = '0' + (n % 10);
        n /= 10;
    }

    while (i > 0)
    {
        uart_tx(b[--i]);
    }
}

/* ADC1 Initialization: Channel 0 (PA0), 12-bit, 56 cycles sampling */
static void adc_init(void)
{
    /* 1. Enable GPIOA and ADC1 peripheral clocks */
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;
    RCC->APB2ENR |= RCC_APB2ENR_ADC1EN;

    /* 2. Set PA0 to Analog Mode (MODER0 = 11b) */
    GPIOA->MODER |= (3U << (0 * 2));

    /* 3. Disable pull-up / pull-down on PA0 */
    GPIOA->PUPDR &= ~(3U << (0 * 2));

    /* 4. Reset Control Registers */
    ADC1->CR1 = 0; /* 12-bit resolution, scan mode disabled */
    ADC1->CR2 = 0; /* Right alignment, single conversion mode */

    /* 5. Select Channel 0 for 1st conversion in regular sequence */
    ADC1->SQR1 = 0; /* Total number of conversions = 1 (L[3:0] = 0000b) */
    ADC1->SQR3 = 0; /* SQ1 = Channel 0 */

    /* 6. Set Sampling Time for Channel 0 to 56 cycles (SMP0[2:0] = 011b) */
    ADC1->SMPR2 &= ~(7U << (0 * 3));
    ADC1->SMPR2 |=  (3U << (0 * 3));

    /* 7. Turn on ADC Peripheral */
    ADC1->CR2 |= ADC_CR2_ADON;
}

static uint16_t adc_read(void)
{
    /* Clear previous EOC status flag if set */
    ADC1->SR &= ~ADC_SR_EOC;

    /* Start software conversion */
    ADC1->CR2 |= ADC_CR2_SWSTART;

    /* Poll End Of Conversion flag */
    while (!(ADC1->SR & ADC_SR_EOC));

    /* Return 12-bit conversion value */
    return (uint16_t)ADC1->DR;
}

int main(void)
{
    uint16_t raw_adc;

    uart_init();
    adc_init();

    uart_str("\r\n--- ADC Milestone A (Bare-Metal) ---\r\n");
    uart_str("Rotate potentiometer on PA0...\r\n");

    while (1)
    {
        raw_adc = adc_read();

        uart_str("ADC = ");
        uart_num(raw_adc);
        uart_str("\r\n");

        /* Approximate software delay (~100ms) */
        for (volatile uint32_t i = 0; i < 300000; i++);
    }
}