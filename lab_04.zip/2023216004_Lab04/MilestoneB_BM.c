#include "stm32f4xx.h"
#include <stdint.h>

#define FLASH_KEY1   0x45670123U
#define FLASH_KEY2   0xCDEF89ABU

#define SEC7         7
#define SEC7_BASE    0x08060000U

/* Minimal USART2 initialization for console logging */
static void UART2_Init(void)
{
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;
    RCC->APB1ENR |= RCC_APB1ENR_USART2EN;

    /* Configure PA2 as Alternate Function (AF7) for USART2_TX */
    GPIOA->MODER &= ~(3U << (2 * 2));
    GPIOA->MODER |=  (2U << (2 * 2));
    GPIOA->AFR[0] &= ~(0xFU << (4 * 2));
    GPIOA->AFR[0] |=  (7U << (4 * 2));

    /* 16 MHz HSI clock, 115200 baud: USARTDIV = 16MHz / (16 * 115200) = 8.6805 -> BRR = 0x8B */
    USART2->BRR = 0x008BU;
    USART2->CR1 |= USART_CR1_TE | USART_CR1_UE;
}

static void uart_str(const char *s)
{
    while (*s)
    {
        while (!(USART2->SR & USART_SR_TXE));
        USART2->DR = (uint8_t)(*s++);
    }
}

/* Flash Utility Functions */
static void Flash_Unlock(void)
{
    if (FLASH->CR & FLASH_CR_LOCK)
    {
        FLASH->KEYR = FLASH_KEY1;
        FLASH->KEYR = FLASH_KEY2;
    }
}

static void Flash_Lock(void)
{
    FLASH->CR |= FLASH_CR_LOCK;
}

static void Flash_EraseSector(uint8_t sectorNum)
{
    Flash_Unlock();

    while (FLASH->SR & FLASH_SR_BSY);

    /* Clear EOP flag if set from a prior operation */
    if (FLASH->SR & FLASH_SR_EOP)
    {
        FLASH->SR |= FLASH_SR_EOP;
    }

    /* Clear existing sector selection and SER bit */
    FLASH->CR &= ~(FLASH_CR_SNB | FLASH_CR_SER);
    
    /* Set Sector Erase mode and select target sector */
    FLASH->CR |= FLASH_CR_SER;
    FLASH->CR |= ((uint32_t)sectorNum << FLASH_CR_SNB_Pos);
    FLASH->CR |= FLASH_CR_STRT;

    while (FLASH->SR & FLASH_SR_BSY);

    /* Clear Sector Erase configuration and flags */
    FLASH->CR &= ~FLASH_CR_SER;
    FLASH->SR |= FLASH_SR_EOP;

    Flash_Lock();
}

static void Flash_WriteWord(uint32_t addr, uint32_t data)
{
    Flash_Unlock();

    while (FLASH->SR & FLASH_SR_BSY);

    /* Clear EOP flag if set */
    if (FLASH->SR & FLASH_SR_EOP)
    {
        FLASH->SR |= FLASH_SR_EOP;
    }

    /* Set parallelism to 32-bit (x32) and enable programming mode */
    FLASH->CR &= ~FLASH_CR_PSIZE;
    FLASH->CR |= FLASH_PSIZE_WORD;
    FLASH->CR |= FLASH_CR_PG;

    *(volatile uint32_t *)addr = data;

    while (FLASH->SR & FLASH_SR_BSY);

    /* Disable programming mode and clear EOP */
    FLASH->CR &= ~FLASH_CR_PG;
    FLASH->SR |= FLASH_SR_EOP;

    Flash_Lock();
}

static uint32_t Flash_ReadWord(uint32_t addr)
{
    return *(volatile uint32_t *)addr;
}

/* Milestone B Checkpoint Test */
void Flash_Test_BareMetal(void)
{
    uint32_t x;

    uart_str("\r\n--- Starting Bare-Metal Flash Test (Sector 7) ---\r\n");

    /* 1. Erase Sector 7 */
    Flash_EraseSector(SEC7);

    /* 2. Verify 0xFFFFFFFF */
    x = Flash_ReadWord(SEC7_BASE);
    if (x == 0xFFFFFFFFU)
    {
        uart_str("ERASE OK (Read: 0xFFFFFFFF)\r\n");
    }
    else
    {
        uart_str("ERASE FAIL\r\n");
        return;
    }

    /* 3. Write 0xDEADBEEF */
    Flash_WriteWord(SEC7_BASE, 0xDEADBEEFU);

    /* 4. Verify 0xDEADBEEF */
    x = Flash_ReadWord(SEC7_BASE);
    if (x == 0xDEADBEEFU)
    {
        uart_str("WRITE/READ OK (Read: 0xDEADBEEF)\r\n");
    }
    else
    {
        uart_str("WRITE/READ FAIL\r\n");
    }
}

int main(void)
{
    UART2_Init();
    
    Flash_Test_BareMetal();

    while (1)
    {
        /* Loop indefinitely */
    }
}