#include "main.h"
#include <stdio.h>

#define SEC7_BASE 0x08060000U

UART_HandleTypeDef huart2;

void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART2_UART_Init(void);

/* Flash Utility Functions using HAL Drivers */
static void Flash_EraseSector_HAL(uint32_t sector)
{
    FLASH_EraseInitTypeDef e;
    uint32_t err;

    HAL_FLASH_Unlock();

    e.TypeErase    = FLASH_TYPEERASE_SECTORS;
    e.Sector       = sector;
    e.NbSectors    = 1;
    e.VoltageRange = FLASH_VOLTAGE_RANGE_3; /* 2.7V to 3.6V operation */

    HAL_FLASHEx_Erase(&e, &err);

    HAL_FLASH_Lock();
}

static void Flash_WriteWord_HAL(uint32_t addr, uint32_t data)
{
    HAL_FLASH_Unlock();

    HAL_FLASH_Program(FLASH_TYPEPROGRAM_WORD, addr, (uint64_t)data);

    HAL_FLASH_Lock();
}

static uint32_t Flash_ReadWord_HAL(uint32_t addr)
{
    return *(volatile uint32_t *)addr;
}

/* Milestone B Checkpoint Test */
void Flash_Test_HAL(void)
{
    uint32_t x;

    printf("\r\n--- Starting HAL Flash Test (Sector 7) ---\r\n");

    /* 1. Erase Sector 7 */
    Flash_EraseSector_HAL(FLASH_SECTOR_7);

    /* 2. Verify 0xFFFFFFFF */
    x = Flash_ReadWord_HAL(SEC7_BASE);
    if (x == 0xFFFFFFFFU)
    {
        printf("ERASE OK (Read: 0xFFFFFFFF)\r\n");
    }
    else
    {
        printf("ERASE FAIL (Read: 0x%08LX)\r\n", (unsigned long)x);
        return;
    }

    /* 3. Write 0xDEADBEEF */
    Flash_WriteWord_HAL(SEC7_BASE, 0xDEADBEEFU);

    /* 4. Verify 0xDEADBEEF */
    x = Flash_ReadWord_HAL(SEC7_BASE);
    if (x == 0xDEADBEEFU)
    {
        printf("WRITE/READ OK (Read: 0xDEADBEEF)\r\n");
    }
    else
    {
        printf("WRITE/READ FAIL (Read: 0x%08LX)\r\n", (unsigned long)x);
    }
}

int main(void)
{
    HAL_Init();
    SystemClock_Config();
    
    MX_GPIO_Init();
    MX_USART2_UART_Init();

    /* Run the HAL sector 7 test sequence */
    Flash_Test_HAL();

    while (1)
    {
    }
}

/* Redirect printf output to USART2 */
int _write(int file, char *ptr, int len)
{
    HAL_UART_Transmit(&huart2, (uint8_t *)ptr, len, HAL_MAX_DELAY);
    return len;
}

static void MX_USART2_UART_Init(void)
{
    huart2.Instance = USART2;
    huart2.Init.BaudRate = 115200;
    huart2.Init.WordLength = UART_WORDLENGTH_8B;
    huart2.Init.StopBits = UART_STOPBITS_1;
    huart2.Init.Parity = UART_PARITY_NONE;
    huart2.Init.Mode = UART_MODE_TX_RX;
    huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
    huart2.Init.OverSampling = UART_OVERSAMPLING_16;
    if (HAL_UART_Init(&huart2) != HAL_OK)
    {
        Error_Handler();
    }
}

static void MX_GPIO_Init(void)
{
    __HAL_RCC_GPIOA_CLK_ENABLE();
}

void SystemClock_Config(void)
{
    /* Standard HSI system clock configuration */
}

void Error_Handler(void)
{
    __disable_irq();
    while (1) {}
}