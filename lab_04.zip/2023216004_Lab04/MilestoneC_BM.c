#include "stm32f4xx.h"
#include <stdint.h>
#include <string.h>

/* --- Hardware & Memory Defines --- */
#define FLASH_KEY1      0x45670123U
#define FLASH_KEY2      0xCDEF89ABU

#define SEC6_BASE       0x08040000U  /* Flash Sector 6: Student Identity */
#define SEC7_BASE       0x08060000U  /* Flash Sector 7: Test Results */

#define ID_MARKER       0xB1010001U  /* Identity Block Valid Marker */

/* --- Identity Structure (64 Bytes Total, 4-Byte Aligned) --- */
typedef struct
{
    uint32_t marker;         /* 4 Bytes: 0xB1010001 if valid, 0xFFFFFFFF if blank */
    char registration[16];   /* 16 Bytes: Null-padded registration string */
    char roll[12];           /* 12 Bytes: Null-padded roll number string */
    char name[32];           /* 32 Bytes: Null-padded student name string */
} StudentInfo_t;

/* --- Bare-Metal UART Utility Functions --- */
static void uart_init(void)
{
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;
    RCC->APB1ENR |= RCC_APB1ENR_USART2EN;

    /* Configure PA2 (TX) and PA3 (RX) as Alternate Function (AF7) */
    GPIOA->MODER &= ~((3U << (2 * 2)) | (3U << (2 * 3)));
    GPIOA->MODER |=  ((2U << (2 * 2)) | (2U << (2 * 3)));

    GPIOA->AFR[0] &= ~((0xFU << (4 * 2)) | (0xFU << (4 * 3)));
    GPIOA->AFR[0] |=  ((7U << (4 * 2))   | (7U << (4 * 3)));

    /* 16 MHz HSI -> BRR = 0x008B for 115200 Baud */
    USART2->BRR = 0x008BU;
    USART2->CR1 = USART_CR1_TE | USART_CR1_RE | USART_CR1_UE;
}

static void uart_tx(char c)
{
    while (!(USART2->SR & USART_SR_TXE));
    USART2->DR = (uint8_t)c;
}

static void uart_str(const char *s)
{
    while (*s)
    {
        uart_tx(*s++);
    }
}

/* --- Bare-Metal Flash Low-Level Driver --- */
static void Flash_Unlock(void)
{
    if (FLASH->CR & FLASH_CR_LOCK)
    {
        FLASH->KEYR = FLASH_KEY1;
        FLASH->KEYR = FLASH_KEY2;
    }
}

static void Flash_Lock(void)
{
    FLASH->CR |= FLASH_CR_LOCK;
}

static void Flash_EraseSector(uint8_t sectorNum)
{
    Flash_Unlock();

    while (FLASH->SR & FLASH_SR_BSY);

    if (FLASH->SR & FLASH_SR_EOP)
    {
        FLASH->SR |= FLASH_SR_EOP;
    }

    /* Clear existing sector selection and erase mode */
    FLASH->CR &= ~(FLASH_CR_SNB | FLASH_CR_SER);
    
    /* Set Sector Erase mode and program target sector */
    FLASH->CR |= FLASH_CR_SER;
    FLASH->CR |= ((uint32_t)sectorNum << FLASH_CR_SNB_Pos);
    FLASH->CR |= FLASH_CR_STRT;

    while (FLASH->SR & FLASH_SR_BSY);

    FLASH->CR &= ~FLASH_CR_SER;
    FLASH->SR |= FLASH_SR_EOP;

    Flash_Lock();
}

static void Flash_WriteWord(uint32_t addr, uint32_t data)
{
    Flash_Unlock();

    while (FLASH->SR & FLASH_SR_BSY);

    if (FLASH->SR & FLASH_SR_EOP)
    {
        FLASH->SR |= FLASH_SR_EOP;
    }

    /* Program parallelism x32 and set PG bit */
    FLASH->CR &= ~FLASH_CR_PSIZE;
    FLASH->CR |= FLASH_PSIZE_WORD;
    FLASH->CR |= FLASH_CR_PG;

    *(volatile uint32_t *)addr = data;

    while (FLASH->SR & FLASH_SR_BSY);

    FLASH->CR &= ~FLASH_CR_PG;
    FLASH->SR |= FLASH_SR_EOP;

    Flash_Lock();
}

static uint32_t Flash_ReadWord(uint32_t addr)
{
    return *(volatile uint32_t *)addr;
}

/* --- Milestone C Identification Functions --- */

/**
 * @brief One-time provisioning routine to erase Sector 6 and write identity details.
 *        MUST ONLY BE RUN ONCE manually, never automatically at every boot!
 */
static void provision_student(void)
{
    StudentInfo_t s;

    s.marker = ID_MARKER;

    /* Zero out arrays completely to ensure proper null-padding */
    memset(s.registration, 0, sizeof(s.registration));
    memset(s.roll, 0, sizeof(s.roll));
    memset(s.name, 0, sizeof(s.name));

    /* Replace with your actual student credentials */
    strcpy(s.registration, "REG123456");
    strcpy(s.roll, "61");
    strcpy(s.name, "Shahriar Islam");

    /* Step 1: Erase identity sector (Sector 6) */
    Flash_EraseSector(6);

    /* Step 2: Write 64 bytes word-by-word (16 words total) */
    for (uint32_t i = 0; i < sizeof(StudentInfo_t); i += 4)
    {
        uint32_t word;
        memcpy(&word, ((uint8_t *)&s) + i, 4);
        Flash_WriteWord(SEC6_BASE + i, word);
    }
}

static uint8_t student_valid(void)
{
    return (Flash_ReadWord(SEC6_BASE) == ID_MARKER);
}

static void read_student(StudentInfo_t *s)
{
    for (uint32_t i = 0; i < sizeof(StudentInfo_t); i += 4)
    {
        uint32_t word = Flash_ReadWord(SEC6_BASE + i);
        memcpy(((uint8_t *)s) + i, &word, 4);
    }
}

static void display_student(void)
{
    StudentInfo_t s;

    if (!student_valid())
    {
        uart_str("\r\nStudent identity: not yet provisioned\r\n");
        return;
    }

    read_student(&s);

    uart_str("\r\nStudent Information\r\n");
    uart_str("---------------------\r\n");
    uart_str("Registration: ");
    uart_str(s.registration);
    uart_str("\r\n");
    uart_str("Roll: ");
    uart_str(s.roll);
    uart_str("\r\n");
    uart_str("Name: ");
    uart_str(s.name);
    uart_str("\r\n");
}

int main(void)
{
    uart_init();

    /* ---------------------------------------------------------------------
     * ONE-TIME PROVISIONING STEP:
     * Uncomment 'provision_student()' ONLY ONCE to flash identity to Sector 6.
     * After provisioning succeeds, comment it back out so Sector 6 is protected.
     * --------------------------------------------------------------------- */
    // provision_student();

    /* Display student identity at every boot */
    display_student();

    while (1)
    {
        /* Ready for next milestone logic */
    }
}