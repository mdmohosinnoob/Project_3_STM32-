#include "main.h"
#include <stdio.h>
#include <string.h>

#define SEC6_BASE   0x08040000U
#define SEC7_BASE   0x08060000U
#define ID_MARKER   0xB1010001U

typedef struct
{
    uint32_t marker;
    char registration[16];
    char roll[12];
    char name[32];
} StudentInfo_t;

UART_HandleTypeDef huart2;

void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART2_UART_Init(void);

/* --- HAL Flash Driver Utility Wrappers --- */
static void Flash_EraseSector_HAL(uint32_t sector)
{
    FLASH_EraseInitTypeDef eraseInit;
    uint32_t sectorError;

    HAL_FLASH_Unlock();

    eraseInit.TypeErase    = FLASH_TYPEERASE_SECTORS;
    eraseInit.Sector       = sector;
    eraseInit.NbSectors    = 1;
    eraseInit.VoltageRange = FLASH_VOLTAGE_RANGE_3;

    HAL_FLASHEx_Erase(&eraseInit, &sectorError);

    HAL_FLASH_Lock();
}

static void Flash_WriteWord_HAL(uint32_t addr, uint32_t data)
{
    HAL_FLASH_Unlock();

    HAL_FLASH_Program(FLASH_TYPEPROGRAM_WORD, addr, (uint64_t)data);

    HAL_FLASH_Lock();
}

static uint32_t Flash_ReadWord_HAL(uint32_t addr)
{
    return *(volatile uint32_t *)addr;
}

/* --- Milestone C Identification Functions (HAL) --- */

/**
 * @brief One-time provisioning routine (HAL version).
 *        MUST ONLY BE RUN ONCE manually!
 */
static void provision_student_HAL(void)
{
    StudentInfo_t s;

    s.marker = ID_MARKER;

    memset(s.registration, 0, sizeof(s.registration));
    memset(s.roll, 0, sizeof(s.roll));
    memset(s.name, 0, sizeof(s.name));

    strcpy(s.registration, "REG123456");
    strcpy(s.roll, "61");
    strcpy(s.name, "Shahriar Islam");

    /* Erase Sector 6 via HAL */
    Flash_EraseSector_HAL(FLASH_SECTOR_6);

    /* Write struct word by word */
    for (uint32_t i = 0; i < sizeof(StudentInfo_t); i += 4)
    {
        uint32_t word;
        memcpy(&word, ((uint8_t *)&s) + i, 4);
        Flash_WriteWord_HAL(SEC6_BASE + i, word);
    }
}

static uint8_t student_valid_HAL(void)
{
    return (Flash_ReadWord_HAL(SEC6_BASE) == ID_MARKER);
}

static void read_student_HAL(StudentInfo_t *s)
{
    for (uint32_t i = 0; i < sizeof(StudentInfo_t); i += 4)
    {
        uint32_t word = Flash_ReadWord_HAL(SEC6_BASE + i);
        memcpy(((uint8_t *)s) + i, &word, 4);
    }
}

static void display_student_HAL(void)
{
    StudentInfo_t s;

    if (!student_valid_HAL())
    {
        printf("\r\nStudent identity: not yet provisioned\r\n");
        return;
    }

    read_student_HAL(&s);

    printf("\r\nStudent Information\r\n");
    printf("---------------------\r\n");
    printf("Registration: %s\r\n", s.registration);
    printf("Roll: %s\r\n", s.roll);
    printf("Name: %s\r\n", s.name);
}

int main(void)
{
    HAL_Init();
    SystemClock_Config();

    MX_GPIO_Init();
    MX_USART2_UART_Init();

    /* ---------------------------------------------------------------------
     * ONE-TIME PROVISIONING STEP:
     * Uncomment 'provision_student_HAL()' ONLY ONCE to flash Sector 6.
     * Comment out again after initial run to prevent repeated sector erasures.
     * --------------------------------------------------------------------- */
    // provision_student_HAL();

    /* Display student identity at boot */
    display_student_HAL();

    while (1)
    {
    }
}

int _write(int file, char *ptr, int len)
{
    HAL_UART_Transmit(&huart2, (uint8_t *)ptr, len, HAL_MAX_DELAY);
    return len;
}

static void MX_USART2_UART_Init(void)
{
    huart2.Instance                  = USART2;
    huart2.Init.BaudRate             = 115200;
    huart2.Init.WordLength           = UART_WORDLENGTH_8B;
    huart2.Init.StopBits             = UART_STOPBITS_1;
    huart2.Init.Parity               = UART_PARITY_NONE;
    huart2.Init.Mode                 = UART_MODE_TX_RX;
    huart2.Init.HwFlowCtl            = UART_HWCONTROL_NONE;
    huart2.Init.OverSampling         = UART_OVERSAMPLING_16;

    if (HAL_UART_Init(&huart2) != HAL_OK)
    {
        Error_Handler();
    }
}

static void MX_GPIO_Init(void)
{
    __HAL_RCC_GPIOA_CLK_ENABLE();
}

void SystemClock_Config(void)
{
}

void Error_Handler(void)
{
    __disable_irq();
    while (1) {}
}