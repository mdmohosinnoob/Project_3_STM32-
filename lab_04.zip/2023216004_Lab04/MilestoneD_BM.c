#include "stm32f4xx.h"
#include <stdint.h>
#include <string.h>
#include <stdio.h>

/* --- Flash and Sector Memory Map --- */
#define FLASH_KEY1      0x45670123U
#define FLASH_KEY2      0xCDEF89ABU

#define SEC6_BASE       0x08040000U  /* Sector 6: Student Identity */
#define SEC7_BASE       0x08060000U  /* Sector 7: Test Results */

#define ID_MARKER       0xB1010001U  /* Identity Marker */
#define TEST_MARKER     0xCAFEBABEU  /* Test Results Marker */

#define VREF_PLUS       3.3f         /* Reference Voltage (3.3V) */
#define NUM_SAMPLES     16           /* N = 16 Samples per resolution */

/* --- Data Structures --- */
typedef struct {
    uint32_t marker;
    char registration[16];
    char roll[12];
    char name[32];
} StudentInfo_t;

typedef struct {
    uint32_t marker;
    float v_12bit;
    float v_10bit;
    float v_8bit;
    float v_6bit;
} TestResults_t;

/* --- Register-Level UART Driver --- */
static void uart_init(void)
{
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;
    RCC->APB1ENR |= RCC_APB1ENR_USART2EN;

    /* Configure PA2 (TX) and PA3 (RX) as Alternate Function (AF7) */
    GPIOA->MODER &= ~((3U << (2 * 2)) | (3U << (2 * 3)));
    GPIOA->MODER |=  ((2U << (2 * 2)) | (2U << (2 * 3)));

    GPIOA->AFR[0] &= ~((0xFU << (4 * 2)) | (0xFU << (4 * 3)));
    GPIOA->AFR[0] |=  ((7U << (4 * 2))   | (7U << (4 * 3)));

    /* 16 MHz HSI -> BRR = 0x008B for 115200 Baud */
    USART2->BRR = 0x008BU;
    USART2->CR1 = USART_CR1_TE | USART_CR1_RE | USART_CR1_UE;
}

static void uart_tx(char c)
{
    while (!(USART2->SR & USART_SR_TXE));
    USART2->DR = (uint8_t)c;
}

static void uart_str(const char *s)
{
    while (*s)
    {
        uart_tx(*s++);
    }
}

/* Polling check for UART received byte (RXNE flag) */
static uint8_t uart_rx_ready(void)
{
    return (USART2->SR & USART_SR_RXNE) ? 1 : 0;
}

static uint8_t uart_rx(void)
{
    while (!uart_rx_ready());
    return (uint8_t)USART2->DR;
}

/* Helper function to format and print float values via UART */
static void uart_print_float(const char *label, float val)
{
    char buf[64];
    int int_part = (int)val;
    int frac_part = (int)((val - (float)int_part) * 1000.0f);
    if (frac_part < 0) frac_part = -frac_part;
    
    snprintf(buf, sizeof(buf), "%s%d.%03d V\r\n", label, int_part, frac_part);
    uart_str(buf);
}

/* --- Register-Level ADC Driver --- */
static void adc_init(void)
{
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;
    RCC->APB2ENR |= RCC_APB2ENR_ADC1EN;

    /* PA0 to Analog Mode (MODER0 = 11b) */
    GPIOA->MODER |= (3U << (0 * 2));
    GPIOA->PUPDR &= ~(3U << (0 * 2));

    ADC1->CR1 = 0;
    ADC1->CR2 = 0;

    ADC1->SQR1 = 0; /* 1 conversion */
    ADC1->SQR3 = 0; /* Channel 0 (PA0) */

    /* SMP0 = 011b (56 cycles sampling time) */
    ADC1->SMPR2 &= ~(7U << (0 * 3));
    ADC1->SMPR2 |=  (3U << (0 * 3));

    ADC1->CR2 |= ADC_CR2_ADON;
}

/**
 * @brief Sets ADC Resolution via ADC1_CR1.RES[1:0]
 * @param res_bits 00 = 12-bit, 01 = 10-bit, 10 = 8-bit, 11 = 6-bit
 */
static void adc_set_resolution(uint32_t res_bits)
{
    ADC1->CR1 &= ~ADC_CR1_RES;             /* Clear RES[1:0] bits */
    ADC1->CR1 |= (res_bits << ADC_CR1_RES_Pos); /* Set new resolution */
}

static uint16_t adc_read(void)
{
    ADC1->SR &= ~ADC_SR_EOC;
    ADC1->CR2 |= ADC_CR2_SWSTART;

    while (!(ADC1->SR & ADC_SR_EOC));

    return (uint16_t)ADC1->DR;
}

/* Takes N samples and returns average code */
static uint32_t adc_sample_average(uint8_t n_samples)
{
    uint32_t sum = 0;
    for (uint8_t i = 0; i < n_samples; i++)
    {
        sum += adc_read();
        for (volatile uint32_t d = 0; d < 5000; d++); /* Short sample delay */
    }
    return sum / n_samples;
}

/* --- Bare-Metal Flash Low-Level Functions --- */
static void Flash_Unlock(void)
{
    if (FLASH->CR & FLASH_CR_LOCK)
    {
        FLASH->KEYR = FLASH_KEY1;
        FLASH->KEYR = FLASH_KEY2;
    }
}

static void Flash_Lock(void)
{
    FLASH->CR |= FLASH_CR_LOCK;
}

static void Flash_EraseSector(uint8_t sectorNum)
{
    Flash_Unlock();
    while (FLASH->SR & FLASH_SR_BSY);

    if (FLASH->SR & FLASH_SR_EOP) FLASH->SR |= FLASH_SR_EOP;

    FLASH->CR &= ~(FLASH_CR_SNB | FLASH_CR_SER);
    FLASH->CR |= FLASH_CR_SER;
    FLASH->CR |= ((uint32_t)sectorNum << FLASH_CR_SNB_Pos);
    FLASH->CR |= FLASH_CR_STRT;

    while (FLASH->SR & FLASH_SR_BSY);

    FLASH->CR &= ~FLASH_CR_SER;
    FLASH->SR |= FLASH_SR_EOP;
    Flash_Lock();
}

static void Flash_WriteWord(uint32_t addr, uint32_t data)
{
    Flash_Unlock();
    while (FLASH->SR & FLASH_SR_BSY);

    if (FLASH->SR & FLASH_SR_EOP) FLASH->SR |= FLASH_SR_EOP;

    FLASH->CR &= ~FLASH_CR_PSIZE;
    FLASH->CR |= FLASH_PSIZE_WORD;
    FLASH->CR |= FLASH_CR_PG;

    *(volatile uint32_t *)addr = data;

    while (FLASH->SR & FLASH_SR_BSY);

    FLASH->CR &= ~FLASH_CR_PG;
    FLASH->SR |= FLASH_SR_EOP;
    Flash_Lock();
}

static uint32_t Flash_ReadWord(uint32_t addr)
{
    return *(volatile uint32_t *)addr;
}

/* --- Milestone C Identity Helpers --- */
static void read_student(StudentInfo_t *s)
{
    for (uint32_t i = 0; i < sizeof(StudentInfo_t); i += 4)
    {
        uint32_t w = Flash_ReadWord(SEC6_BASE + i);
        memcpy(((uint8_t *)s) + i, &w, 4);
    }
}

static void display_student(void)
{
    StudentInfo_t s;
    if (Flash_ReadWord(SEC6_BASE) != ID_MARKER)
    {
        uart_str("\r\nStudent identity: not yet provisioned\r\n");
        return;
    }

    read_student(&s);
    uart_str("\r\n--- Student Identity (Sector 6) ---\r\n");
    uart_str("Registration: "); uart_str(s.registration); uart_str("\r\n");
    uart_str("Roll        : "); uart_str(s.roll);         uart_str("\r\n");
    uart_str("Name        : "); uart_str(s.name);         uart_str("\r\n");
}

/* --- Milestone E Result Display Helper --- */
static void display_previous_results(void)
{
    if (Flash_ReadWord(SEC7_BASE) != TEST_MARKER)
    {
        uart_str("\r\nTest Results (Sector 7): No previous test data.\r\n");
        return;
    }

    TestResults_t r;
    for (uint32_t i = 0; i < sizeof(TestResults_t); i += 4)
    {
        uint32_t w = Flash_ReadWord(SEC7_BASE + i);
        memcpy(((uint8_t *)&r) + i, &w, 4);
    }

    uart_str("\r\n--- Stored Test Results (Sector 7) ---\r\n");
    uart_print_float("12-bit: ", r.v_12bit);
    uart_print_float("10-bit: ", r.v_10bit);
    uart_print_float(" 8-bit: ", r.v_8bit);
    uart_print_float(" 6-bit: ", r.v_6bit);
}

/* --- Milestone D Multi-Resolution ADC Test Routine --- */
static void run_adc_test_suite(void)
{
    TestResults_t results;
    results.marker = TEST_MARKER;

    uart_str("\r\n========================================\r\n");
    uart_str("Starting Multi-Resolution Test Suite...\r\n");
    uart_str("========================================\r\n");

    /* 1. 12-bit Resolution (RES = 00b, Max Code = 4095) */
    adc_set_resolution(0x0);
    uint32_t avg_12 = adc_sample_average(NUM_SAMPLES);
    results.v_12bit = ((float)avg_12 / 4095.0f) * VREF_PLUS;
    uart_print_float("12-bit Avg Voltage: ", results.v_12bit);

    /* 2. 10-bit Resolution (RES = 01b, Max Code = 1023) */
    adc_set_resolution(0x1);
    uint32_t avg_10 = adc_sample_average(NUM_SAMPLES);
    results.v_10bit = ((float)avg_10 / 1023.0f) * VREF_PLUS;
    uart_print_float("10-bit Avg Voltage: ", results.v_10bit);

    /* 3. 8-bit Resolution (RES = 10b, Max Code = 255) */
    adc_set_resolution(0x2);
    uint32_t avg_8 = adc_sample_average(NUM_SAMPLES);
    results.v_8bit = ((float)avg_8 / 255.0f) * VREF_PLUS;
    uart_print_float(" 8-bit Avg Voltage: ", results.v_8bit);

    /* 4. 6-bit Resolution (RES = 11b, Max Code = 63) */
    adc_set_resolution(0x3);
    uint32_t avg_6 = adc_sample_average(NUM_SAMPLES);
    results.v_6bit = ((float)avg_6 / 63.0f) * VREF_PLUS;
    uart_print_float(" 6-bit Avg Voltage: ", results.v_6bit);

    /* Restore ADC to default 12-bit */
    adc_set_resolution(0x0);

    /* Store all 4 results in Flash Sector 7 */
    uart_str("\r\nErasing Sector 7 and saving results...\r\n");
    Flash_EraseSector(7);

    for (uint32_t i = 0; i < sizeof(TestResults_t); i += 4)
    {
        uint32_t w;
        memcpy(&w, ((uint8_t *)&results) + i, 4);
        Flash_WriteWord(SEC7_BASE + i, w);
    }

    uart_str("Flash write complete! Sector 7 updated successfully.\r\n");
    uart_str("Press any key to re-run the test suite...\r\n");
}

int main(void)
{
    uart_init();
    adc_init();

    /* Step 1 & 2 of Milestone E Boot Sequence */
    display_student();
    display_previous_results();

    uart_str("\r\n[SYSTEM READY] Press any key on UART terminal to start ADC test...\r\n");

    while (1)
    {
        /* Milestone D UART Auto-Trigger with Debounce */
        if (uart_rx_ready())
        {
            (void)uart_rx(); /* Read incoming byte to clear RXNE */

            /* Debounce delay: drain any extra bytes sent in rapid succession */
            for (volatile uint32_t delay = 0; delay < 2000000; delay++);
            while (uart_rx_ready()) { (void)uart_rx(); }

            /* Run multi-resolution test sequence */
            run_adc_test_suite();
        }
    }
}