#include "main.h"
#include <stdio.h>
#include <string.h>

#define SEC6_BASE       0x08040000U
#define SEC7_BASE       0x08060000U

#define ID_MARKER       0xB1010001U
#define TEST_MARKER     0xCAFEBABEU

#define VREF_PLUS       3.3f
#define NUM_SAMPLES     16

typedef struct {
    uint32_t marker;
    char registration[16];
    char roll[12];
    char name[32];
} StudentInfo_t;

typedef struct {
    uint32_t marker;
    float v_12bit;
    float v_10bit;
    float v_8bit;
    float v_6bit;
} TestResults_t;

ADC_HandleTypeDef hadc1;
UART_HandleTypeDef huart2;

void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_ADC1_Init(void);
static void MX_USART2_UART_Init(void);

/* --- HAL Flash Utilities --- */
static void Flash_EraseSector_HAL(uint32_t sector)
{
    FLASH_EraseInitTypeDef e;
    uint32_t err;

    HAL_FLASH_Unlock();
    e.TypeErase    = FLASH_TYPEERASE_SECTORS;
    e.Sector       = sector;
    e.NbSectors    = 1;
    e.VoltageRange = FLASH_VOLTAGE_RANGE_3;
    HAL_FLASHEx_Erase(&e, &err);
    HAL_FLASH_Lock();
}

static void Flash_WriteWord_HAL(uint32_t addr, uint32_t data)
{
    HAL_FLASH_Unlock();
    HAL_FLASH_Program(FLASH_TYPEPROGRAM_WORD, addr, (uint64_t)data);
    HAL_FLASH_Lock();
}

static uint32_t Flash_ReadWord_HAL(uint32_t addr)
{
    return *(volatile uint32_t *)addr;
}

/* --- Re-configure ADC Resolution via HAL --- */
static void HAL_ADC_ReconfigResolution(uint32_t resolution)
{
    hadc1.Init.Resolution = resolution;
    HAL_ADC_Init(&hadc1);
}

static uint32_t HAL_ADC_SampleAverage(uint8_t n_samples)
{
    uint32_t sum = 0;
    for (uint8_t i = 0; i < n_samples; i++)
    {
        HAL_ADC_Start(&hadc1);
        if (HAL_ADC_PollForConversion(&hadc1, 10) == HAL_OK)
        {
            sum += HAL_ADC_GetValue(&hadc1);
        }
        HAL_ADC_Stop(&hadc1);
        HAL_Delay(5);
    }
    return sum / n_samples;
}

/* --- Milestone C Identity Display (HAL) --- */
static void display_student_HAL(void)
{
    if (Flash_ReadWord_HAL(SEC6_BASE) != ID_MARKER)
    {
        printf("\r\nStudent identity: not yet provisioned\r\n");
        return;
    }

    StudentInfo_t s;
    for (uint32_t i = 0; i < sizeof(StudentInfo_t); i += 4)
    {
        uint32_t w = Flash_ReadWord_HAL(SEC6_BASE + i);
        memcpy(((uint8_t *)&s) + i, &w, 4);
    }

    printf("\r\n--- Student Identity (Sector 6) ---\r\n");
    printf("Registration: %s\r\n", s.registration);
    printf("Roll        : %s\r\n", s.roll);
    printf("Name        : %s\r\n", s.name);
}

/* --- Milestone E Previous Results Display (HAL) --- */
static void display_previous_results_HAL(void)
{
    if (Flash_ReadWord_HAL(SEC7_BASE) != TEST_MARKER)
    {
        printf("\r\nTest Results (Sector 7): No previous test data.\r\n");
        return;
    }

    TestResults_t r;
    for (uint32_t i = 0; i < sizeof(TestResults_t); i += 4)
    {
        uint32_t w = Flash_ReadWord_HAL(SEC7_BASE + i);
        memcpy(((uint8_t *)&r) + i, &w, 4);
    }

    printf("\r\n--- Stored Test Results (Sector 7) ---\r\n");
    printf("12-bit: %.3f V\r\n", r.v_12bit);
    printf("10-bit: %.3f V\r\n", r.v_10bit);
    printf(" 8-bit: %.3f V\r\n", r.v_8bit);
    printf(" 6-bit: %.3f V\r\n", r.v_6bit);
}

/* --- Milestone D Test Suite (HAL) --- */
static void run_adc_test_suite_HAL(void)
{
    TestResults_t results;
    results.marker = TEST_MARKER;

    printf("\r\n========================================\r\n");
    printf("Starting Multi-Resolution Test Suite...\r\n");
    printf("========================================\r\n");

    /* 1. 12-bit (Max Code = 4095) */
    HAL_ADC_ReconfigResolution(ADC_RESOLUTION_12B);
    uint32_t avg_12 = HAL_ADC_SampleAverage(NUM_SAMPLES);
    results.v_12bit = ((float)avg_12 / 4095.0f) * VREF_PLUS;
    printf("12-bit Avg Voltage: %.3f V\r\n", results.v_12bit);

    /* 2. 10-bit (Max Code = 1023) */
    HAL_ADC_ReconfigResolution(ADC_RESOLUTION_10B);
    uint32_t avg_10 = HAL_ADC_SampleAverage(NUM_SAMPLES);
    results.v_10bit = ((float)avg_10 / 1023.0f) * VREF_PLUS;
    printf("10-bit Avg Voltage: %.3f V\r\n", results.v_10bit);

    /* 3. 8-bit (Max Code = 255) */
    HAL_ADC_ReconfigResolution(ADC_RESOLUTION_8B);
    uint32_t avg_8 = HAL_ADC_SampleAverage(NUM_SAMPLES);
    results.v_8bit = ((float)avg_8 / 255.0f) * VREF_PLUS;
    printf(" 8-bit Avg Voltage: %.3f V\r\n", results.v_8bit);

    /* 4. 6-bit (Max Code = 63) */
    HAL_ADC_ReconfigResolution(ADC_RESOLUTION_6B);
    uint32_t avg_6 = HAL_ADC_SampleAverage(NUM_SAMPLES);
    results.v_6bit = ((float)avg_6 / 63.0f) * VREF_PLUS;
    printf(" 6-bit Avg Voltage: %.3f V\r\n", results.v_6bit);

    /* Restore default resolution */
    HAL_ADC_ReconfigResolution(ADC_RESOLUTION_12B);

    /* Save results to Sector 7 */
    printf("\r\nErasing Sector 7 and saving results...\r\n");
    Flash_EraseSector_HAL(FLASH_SECTOR_7);

    for (uint32_t i = 0; i < sizeof(TestResults_t); i += 4)
    {
        uint32_t w;
        memcpy(&w, ((uint8_t *)&results) + i, 4);
        Flash_WriteWord_HAL(SEC7_BASE + i, w);
    }

    printf("Flash write complete! Sector 7 updated successfully.\r\n");
    printf("Press any key to re-run the test suite...\r\n");
}

int main(void)
{
    uint8_t rx_byte;

    HAL_Init();
    SystemClock_Config();

    MX_GPIO_Init();
    MX_USART2_UART_Init();
    MX_ADC1_Init();

    /* Boot Display Sequence */
    display_student_HAL();
    display_previous_results_HAL();

    printf("\r\n[SYSTEM READY] Press any key on UART terminal to start ADC test...\r\n");

    while (1)
    {
        /* Poll UART for trigger byte (10 ms timeout) */
        if (HAL_UART_Receive(&huart2, &rx_byte, 1, 10) == HAL_OK)
        {
            HAL_Delay(200); /* Software debounce delay */
            __HAL_UART_FLUSH_DRREGISTER(&huart2); /* Flush rx buffer */

            run_adc_test_suite_HAL();
        }
    }
}

int _write(int file, char *ptr, int len)
{
    HAL_UART_Transmit(&huart2, (uint8_t *)ptr, len, HAL_MAX_DELAY);
    return len;
}

static void MX_ADC1_Init(void)
{
    ADC_ChannelConfTypeDef sConfig = {0};

    hadc1.Instance                   = ADC1;
    hadc1.Init.ClockPrescaler        = ADC_CLOCK_SYNC_PCLK_DIV4;
    hadc1.Init.Resolution            = ADC_RESOLUTION_12B;
    hadc1.Init.ScanConvMode          = DISABLE;
    hadc1.Init.ContinuousConvMode    = DISABLE;
    hadc1.Init.DiscontinuousConvMode = DISABLE;
    hadc1.Init.ExternalTrigConvEdge  = ADC_EXTERNALTRIGCONVEDGE_NONE;
    hadc1.Init.ExternalTrigConv      = ADC_SOFTWARE_START;
    hadc1.Init.DataAlign             = ADC_DATAALIGN_RIGHT;
    hadc1.Init.NbrOfConversion       = 1;
    hadc1.Init.DMAContinuousRequests = DISABLE;
    hadc1.Init.EOCSelection          = ADC_EOC_SINGLE_CONV;
    HAL_ADC_Init(&hadc1);

    sConfig.Channel      = ADC_CHANNEL_0;
    sConfig.Rank         = 1;
    sConfig.SamplingTime = ADC_SAMPLETIME_56CYCLES;
    HAL_ADC_ConfigChannel(&hadc1, &sConfig);
}

static void MX_USART2_UART_Init(void)
{
    huart2.Instance          = USART2;
    huart2.Init.BaudRate     = 115200;
    huart2.Init.WordLength   = UART_WORDLENGTH_8B;
    huart2.Init.StopBits     = UART_STOPBITS_1;
    huart2.Init.Parity       = UART_PARITY_NONE;
    huart2.Init.Mode         = UART_MODE_TX_RX;
    huart2.Init.HwFlowCtl    = UART_HWCONTROL_NONE;
    huart2.Init.OverSampling = UART_OVERSAMPLING_16;
    HAL_UART_Init(&huart2);
}

static void MX_GPIO_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};
    __HAL_RCC_GPIOA_CLK_ENABLE();
    GPIO_InitStruct.Pin  = GPIO_PIN_0;
    GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
}

void SystemClock_Config(void) {}
void Error_Handler(void) { __disable_irq(); while (1); }