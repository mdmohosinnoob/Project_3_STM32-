#include "stm32f4xx.h"
#include <stdint.h>
#include <string.h>
#include <stdio.h>

#define SEC6_BASE       0x08040000U  /* Sector 6 Base Address */
#define SEC7_BASE       0x08060000U  /* Sector 7 Base Address */

#define ID_MARKER       0xB1010001U  /* Milestone C Marker */
#define TEST_MARKER     0xCAFEBABEU  /* Milestone D Marker */

typedef struct {
    uint32_t marker;
    char registration[16];
    char roll[12];
    char name[32];
} StudentInfo_t;

typedef struct {
    uint32_t marker;
    float v_12bit;
    float v_10bit;
    float v_8bit;
    float v_6bit;
} TestResults_t;

/* Low-level UART Helpers */
static void uart_init(void)
{
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;
    RCC->APB1ENR |= RCC_APB1ENR_USART2EN;

    GPIOA->MODER &= ~((3U << (2 * 2)) | (3U << (2 * 3)));
    GPIOA->MODER |=  ((2U << (2 * 2)) | (2U << (2 * 3)));

    GPIOA->AFR[0] &= ~((0xFU << (4 * 2)) | (0xFU << (4 * 3)));
    GPIOA->AFR[0] |=  ((7U << (4 * 2))   | (7U << (4 * 3)));

    USART2->BRR = 0x008BU; /* 115200 Baud @ 16MHz */
    USART2->CR1 = USART_CR1_TE | USART_CR1_RE | USART_CR1_UE;
}

static void uart_tx(char c)
{
    while (!(USART2->SR & USART_SR_TXE));
    USART2->DR = (uint8_t)c;
}

static void uart_str(const char *s)
{
    while (*s) uart_tx(*s++);
}

static void uart_print_float(const char *label, float val)
{
    char buf[64];
    int int_part = (int)val;
    int frac_part = (int)((val - (float)int_part) * 1000.0f);
    if (frac_part < 0) frac_part = -frac_part;
    
    snprintf(buf, sizeof(buf), "%s%d.%03d V\r\n", label, int_part, frac_part);
    uart_str(buf);
}

static uint32_t Flash_ReadWord(uint32_t addr)
{
    return *(volatile uint32_t *)addr;
}

/* --- Milestone E Dedicated Functions --- */

/**
 * @brief Reads and displays Sector 6 Student Credentials
 */
void Boot_DisplayStudentInfo(void)
{
    uint32_t marker = Flash_ReadWord(SEC6_BASE);

    if (marker != ID_MARKER)
    {
        uart_str("\r\n========================================\r\n");
        uart_str("Student Identity: NOT PROVISIONED\r\n");
        uart_str("========================================\r\n");
        return;
    }

    StudentInfo_t s;
    for (uint32_t i = 0; i < sizeof(StudentInfo_t); i += 4)
    {
        uint32_t w = Flash_ReadWord(SEC6_BASE + i);
        memcpy(((uint8_t *)&s) + i, &w, 4);
    }

    uart_str("\r\n========================================\r\n");
    uart_str("       STUDENT IDENTITY (Sector 6)      \r\n");
    uart_str("========================================\r\n");
    uart_str("Registration : "); uart_str(s.registration); uart_str("\r\n");
    uart_str("Roll Number  : "); uart_str(s.roll);         uart_str("\r\n");
    uart_str("Name         : "); uart_str(s.name);         uart_str("\r\n");
}

/**
 * @brief Reads and displays Sector 7 Preserved Test Results
 */
void Boot_DisplayPreviousResults(void)
{
    uint32_t marker = Flash_ReadWord(SEC7_BASE);

    if (marker != TEST_MARKER)
    {
        uart_str("\r\n========================================\r\n");
        uart_str("Test Results: NO PREVIOUS DATA FOUND\r\n");
        uart_str("========================================\r\n");
        return;
    }

    TestResults_t r;
    for (uint32_t i = 0; i < sizeof(TestResults_t); i += 4)
    {
        uint32_t w = Flash_ReadWord(SEC7_BASE + i);
        memcpy(((uint8_t *)&r) + i, &w, 4);
    }

    uart_str("\r\n========================================\r\n");
    uart_str("     PREVIOUS TEST RESULTS (Sector 7)   \r\n");
    uart_str("========================================\r\n");
    uart_print_float("12-bit Resolution : ", r.v_12bit);
    uart_print_float("10-bit Resolution : ", r.v_10bit);
    uart_print_float(" 8-bit Resolution : ", r.v_8bit);
    uart_print_float(" 6-bit Resolution : ", r.v_6bit);
}

int main(void)
{
    uart_init();

    /* Milestone E Boot Output Sequence */
    Boot_DisplayStudentInfo();
    Boot_DisplayPreviousResults();

    uart_str("\r\n[SYSTEM READY] Press any key on UART terminal to start ADC test...\r\n");

    while (1)
    {
        /* System waits here for character input to trigger Milestone D suite */
    }
}