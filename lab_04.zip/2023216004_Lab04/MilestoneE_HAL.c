#include "main.h"
#include <stdio.h>
#include <string.h>

#define SEC6_BASE       0x08040000U
#define SEC7_BASE       0x08060000U

#define ID_MARKER       0xB1010001U
#define TEST_MARKER     0xCAFEBABEU

typedef struct {
    uint32_t marker;
    char registration[16];
    char roll[12];
    char name[32];
} StudentInfo_t;

typedef struct {
    uint32_t marker;
    float v_12bit;
    float v_10bit;
    float v_8bit;
    float v_6bit;
} TestResults_t;

UART_HandleTypeDef huart2;

void SystemClock_Config(void);
static void MX_USART2_UART_Init(void);

static uint32_t Flash_ReadWord_HAL(uint32_t addr)
{
    return *(volatile uint32_t *)addr;
}

/* --- Milestone E Boot Display Functions (HAL) --- */

void Boot_DisplayStudentInfo_HAL(void)
{
    if (Flash_ReadWord_HAL(SEC6_BASE) != ID_MARKER)
    {
        printf("\r\n========================================\r\n");
        printf("Student Identity: NOT PROVISIONED\r\n");
        printf("========================================\r\n");
        return;
    }

    StudentInfo_t s;
    for (uint32_t i = 0; i < sizeof(StudentInfo_t); i += 4)
    {
        uint32_t w = Flash_ReadWord_HAL(SEC6_BASE + i);
        memcpy(((uint8_t *)&s) + i, &w, 4);
    }

    printf("\r\n========================================\r\n");
    printf("       STUDENT IDENTITY (Sector 6)      \r\n");
    printf("========================================\r\n");
    printf("Registration : %s\r\n", s.registration);
    printf("Roll Number  : %s\r\n", s.roll);
    printf("Name         : %s\r\n", s.name);
}

void Boot_DisplayPreviousResults_HAL(void)
{
    if (Flash_ReadWord_HAL(SEC7_BASE) != TEST_MARKER)
    {
        printf("\r\n========================================\r\n");
        printf("Test Results: NO PREVIOUS DATA FOUND\r\n");
        printf("========================================\r\n");
        return;
    }

    TestResults_t r;
    for (uint32_t i = 0; i < sizeof(TestResults_t); i += 4)
    {
        uint32_t w = Flash_ReadWord_HAL(SEC7_BASE + i);
        memcpy(((uint8_t *)&r) + i, &w, 4);
    }

    printf("\r\n========================================\r\n");
    printf("     PREVIOUS TEST RESULTS (Sector 7)   \r\n");
    printf("========================================\r\n");
    printf("12-bit Resolution : %.3f V\r\n", r.v_12bit);
    printf("10-bit Resolution : %.3f V\r\n", r.v_10bit);
    printf(" 8-bit Resolution : %.3f V\r\n", r.v_8bit);
    printf(" 6-bit Resolution : %.3f V\r\n", r.v_6bit);
}

int main(void)
{
    HAL_Init();
    SystemClock_Config();
    MX_USART2_UART_Init();

    /* Milestone E Boot Execution */
    Boot_DisplayStudentInfo_HAL();
    Boot_DisplayPreviousResults_HAL();

    printf("\r\n[SYSTEM READY] Press any key on UART terminal to start ADC test...\r\n");

    while (1)
    {
    }
}

int _write(int file, char *ptr, int len)
{
    HAL_UART_Transmit(&huart2, (uint8_t *)ptr, len, HAL_MAX_DELAY);
    return len;
}

static void MX_USART2_UART_Init(void)
{
    huart2.Instance          = USART2;
    huart2.Init.BaudRate     = 115200;
    huart2.Init.WordLength   = UART_WORDLENGTH_8B;
    huart2.Init.StopBits     = UART_STOPBITS_1;
    huart2.Init.Parity       = UART_PARITY_NONE;
    huart2.Init.Mode         = UART_MODE_TX_RX;
    huart2.Init.HwFlowCtl    = UART_HWCONTROL_NONE;
    huart2.Init.OverSampling = UART_OVERSAMPLING_16;
    HAL_UART_Init(&huart2);
}

void SystemClock_Config(void) {}