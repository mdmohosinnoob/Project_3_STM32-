#include "stm32f4xx.h"
#include <stdint.h>
#include <string.h>
#include <stdio.h>

/* ============================================================================
 * FLASH MEMORY MAP & CONSTANTS
 * ============================================================================ */
#define FLASH_KEY1          0x45670123U
#define FLASH_KEY2          0xCDEF89ABU

#define SEC6_BASE           0x08040000U  /* Sector 6: Student Identity */
#define SEC7_BASE           0x08060000U  /* Sector 7: Test Results */

#define ID_MARKER           0xB1010001U  /* Identity Marker */
#define TEST_MARKER         0xCAFEBABEU  /* Test Results Marker */

#define VREF_PLUS           3.3f         /* Analog Reference Voltage (V) */
#define NUM_SAMPLES         16           /* Averaging Sample Count (N=16) */

/* ============================================================================
 * DATA STRUCTURES
 * ============================================================================ */
typedef struct {
    uint32_t marker;
    char registration[16];
    char roll[12];
    char name[32];
} StudentInfo_t;

typedef struct {
    uint32_t marker;
    float v_12bit;
    float v_10bit;
    float v_8bit;
    float v_6bit;
} TestResults_t;

/* ============================================================================
 * BARE-METAL UART DRIVER (USART2 @ 115200 Baud)
 * ============================================================================ */
static void UART2_Init(void)
{
    /* Enable GPIOA and USART2 peripheral clocks */
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;
    RCC->APB1ENR |= RCC_APB1ENR_USART2EN;

    /* PA2 -> TX, PA3 -> RX (Alternate Function 7) */
    GPIOA->MODER &= ~((3U << (2 * 2)) | (3U << (2 * 3)));
    GPIOA->MODER |=  ((2U << (2 * 2)) | (2U << (2 * 3)));

    GPIOA->AFR[0] &= ~((0xFU << (4 * 2)) | (0xFU << (4 * 3)));
    GPIOA->AFR[0] |=  ((7U << (4 * 2))   | (7U << (4 * 3)));

    /* 16 MHz HSI clock: BRR = 16000000 / (16 * 115200) = 8.6875 -> 0x008B */
    USART2->BRR = 0x008BU;
    USART2->CR1 = USART_CR1_TE | USART_CR1_RE | USART_CR1_UE;
}

static void UART2_SendChar(char c)
{
    while (!(USART2->SR & USART_SR_TXE));
    USART2->DR = (uint8_t)c;
}

static void UART2_SendString(const char *s)
{
    while (*s) UART2_SendChar(*s++);
}

static uint8_t UART2_IsRxReady(void)
{
    return (USART2->SR & USART_SR_RXNE) ? 1 : 0;
}

static uint8_t UART2_ReadChar(void)
{
    while (!UART2_IsRxReady());
    return (uint8_t)USART2->DR;
}

static void UART2_PrintFloat(const char *label, float val)
{
    char buf[64];
    int int_part = (int)val;
    int frac_part = (int)((val - (float)int_part) * 1000.0f);
    if (frac_part < 0) frac_part = -frac_part;

    snprintf(buf, sizeof(buf), "%s%d.%03d V\r\n", label, int_part, frac_part);
    UART2_SendString(buf);
}

/* ============================================================================
 * BARE-METAL ADC DRIVER (ADC1 Channel 0 - PA0)
 * ============================================================================ */
static void ADC1_Init(void)
{
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;
    RCC->APB2ENR |= RCC_APB2ENR_ADC1EN;

    /* Configure PA0 as Analog mode */
    GPIOA->MODER |= (3U << (0 * 2));
    GPIOA->PUPDR &= ~(3U << (0 * 2));

    ADC1->CR1 = 0;
    ADC1->CR2 = 0;
    ADC1->SQR1 = 0; /* 1 single conversion */
    ADC1->SQR3 = 0; /* Select Channel 0 */

    /* Sampling time = 56 cycles for Channel 0 */
    ADC1->SMPR2 &= ~(7U << (0 * 3));
    ADC1->SMPR2 |=  (3U << (0 * 3));

    /* Turn ADC ON */
    ADC1->CR2 |= ADC_CR2_ADON;
}

static void ADC1_SetResolution(uint32_t res_bits)
{
    ADC1->CR1 &= ~ADC_CR1_RES;                       /* Clear RES bits */
    ADC1->CR1 |= ((res_bits & 0x3U) << ADC_CR1_RES_Pos); /* Set resolution */
}

static uint16_t ADC1_ReadSingle(void)
{
    ADC1->SR &= ~ADC_SR_EOC;
    ADC1->CR2 |= ADC_CR2_SWSTART;

    while (!(ADC1->SR & ADC_SR_EOC));

    return (uint16_t)ADC1->DR;
}

static uint32_t ADC1_SampleAverage(uint8_t n_samples)
{
    uint32_t sum = 0;
    for (uint8_t i = 0; i < n_samples; i++)
    {
        sum += ADC1_ReadSingle();
        for (volatile uint32_t delay = 0; delay < 4000; delay++);
    }
    return sum / n_samples;
}

/* ============================================================================
 * BARE-METAL FLASH LOW-LEVEL DRIVER
 * ============================================================================ */
static void Flash_Unlock(void)
{
    if (FLASH->CR & FLASH_CR_LOCK)
    {
        FLASH->KEYR = FLASH_KEY1;
        FLASH->KEYR = FLASH_KEY2;
    }
}

static void Flash_Lock(void)
{
    FLASH->CR |= FLASH_CR_LOCK;
}

static void Flash_EraseSector(uint8_t sectorNum)
{
    Flash_Unlock();
    while (FLASH->SR & FLASH_SR_BSY);

    if (FLASH->SR & FLASH_SR_EOP) FLASH->SR |= FLASH_SR_EOP;

    FLASH->CR &= ~(FLASH_CR_SNB | FLASH_CR_SER);
    FLASH->CR |= FLASH_CR_SER;
    FLASH->CR |= ((uint32_t)sectorNum << FLASH_CR_SNB_Pos);
    FLASH->CR |= FLASH_CR_STRT;

    while (FLASH->SR & FLASH_SR_BSY);

    FLASH->CR &= ~FLASH_CR_SER;
    FLASH->SR |= FLASH_SR_EOP;
    Flash_Lock();
}

static void Flash_WriteWord(uint32_t addr, uint32_t data)
{
    Flash_Unlock();
    while (FLASH->SR & FLASH_SR_BSY);

    if (FLASH->SR & FLASH_SR_EOP) FLASH->SR |= FLASH_SR_EOP;

    FLASH->CR &= ~FLASH_CR_PSIZE;
    FLASH->CR |= FLASH_PSIZE_WORD;
    FLASH->CR |= FLASH_CR_PG;

    *(volatile uint32_t *)addr = data;

    while (FLASH->SR & FLASH_SR_BSY);

    FLASH->CR &= ~FLASH_CR_PG;
    FLASH->SR |= FLASH_SR_EOP;
    Flash_Lock();
}

static uint32_t Flash_ReadWord(uint32_t addr)
{
    return *(volatile uint32_t *)addr;
}

/* ============================================================================
 * MILESTONE C: IDENTITY MANAGEMENT
 * ============================================================================ */
void System_ProvisionStudentIdentity(void)
{
    StudentInfo_t s;
    s.marker = ID_MARKER;

    memset(s.registration, 0, sizeof(s.registration));
    memset(s.roll, 0, sizeof(s.roll));
    memset(s.name, 0, sizeof(s.name));

    strcpy(s.registration, "REG123456");
    strcpy(s.roll, "42");
    strcpy(s.name, "Shahriar Islam");

    Flash_EraseSector(6);

    for (uint32_t i = 0; i < sizeof(StudentInfo_t); i += 4)
    {
        uint32_t w;
        memcpy(&w, ((uint8_t *)&s) + i, 4);
        Flash_WriteWord(SEC6_BASE + i, w);
    }
}

static void Boot_DisplayStudentIdentity(void)
{
    if (Flash_ReadWord(SEC6_BASE) != ID_MARKER)
    {
        UART2_SendString("\r\n========================================\r\n");
        UART2_SendString(" Student Identity: NOT PROVISIONED      \r\n");
        UART2_SendString("========================================\r\n");
        return;
    }

    StudentInfo_t s;
    for (uint32_t i = 0; i < sizeof(StudentInfo_t); i += 4)
    {
        uint32_t w = Flash_ReadWord(SEC6_BASE + i);
        memcpy(((uint8_t *)&s) + i, &w, 4);
    }

    UART2_SendString("\r\n========================================\r\n");
    UART2_SendString("       STUDENT IDENTITY (Sector 6)      \r\n");
    UART2_SendString("========================================\r\n");
    UART2_SendString(" Registration : "); UART2_SendString(s.registration); UART2_SendString("\r\n");
    UART2_SendString(" Roll Number  : "); UART2_SendString(s.roll);         UART2_SendString("\r\n");
    UART2_SendString(" Name         : "); UART2_SendString(s.name);         UART2_SendString("\r\n");
}

/* ============================================================================
 * MILESTONE E: PREVIOUS TEST DISPLAY
 * ============================================================================ */
static void Boot_DisplayPreviousResults(void)
{
    if (Flash_ReadWord(SEC7_BASE) != TEST_MARKER)
    {
        UART2_SendString("\r\n========================================\r\n");
        UART2_SendString(" Test Results: NO PREVIOUS DATA FOUND   \r\n");
        UART2_SendString("========================================\r\n");
        return;
    }

    TestResults_t r;
    for (uint32_t i = 0; i < sizeof(TestResults_t); i += 4)
    {
        uint32_t w = Flash_ReadWord(SEC7_BASE + i);
        memcpy(((uint8_t *)&r) + i, &w, 4);
    }

    UART2_SendString("\r\n========================================\r\n");
    UART2_SendString("     PREVIOUS TEST RESULTS (Sector 7)   \r\n");
    UART2_SendString("========================================\r\n");
    UART2_PrintFloat(" 12-bit Resolution : ", r.v_12bit);
    UART2_PrintFloat(" 10-bit Resolution : ", r.v_10bit);
    UART2_PrintFloat("  8-bit Resolution : ", r.v_8bit);
    UART2_PrintFloat("  6-bit Resolution : ", r.v_6bit);
}

/* ============================================================================
 * MILESTONE D: MULTI-RESOLUTION TEST SUITE
 * ============================================================================ */
static void Run_MultiResolutionTestSuite(void)
{
    TestResults_t results;
    results.marker = TEST_MARKER;

    UART2_SendString("\r\n========================================\r\n");
    UART2_SendString("   RUNNING MULTI-RESOLUTION TEST SUITE  \r\n");
    UART2_SendString("========================================\r\n");

    /* 1. 12-bit Mode (Max = 4095) */
    ADC1_SetResolution(0x0);
    uint32_t avg12 = ADC1_SampleAverage(NUM_SAMPLES);
    results.v_12bit = ((float)avg12 / 4095.0f) * VREF_PLUS;
    UART2_PrintFloat(" [12-bit] Voltage : ", results.v_12bit);

    /* 2. 10-bit Mode (Max = 1023) */
    ADC1_SetResolution(0x1);
    uint32_t avg10 = ADC1_SampleAverage(NUM_SAMPLES);
    results.v_10bit = ((float)avg10 / 1023.0f) * VREF_PLUS;
    UART2_PrintFloat(" [10-bit] Voltage : ", results.v_10bit);

    /* 3. 8-bit Mode (Max = 255) */
    ADC1_SetResolution(0x2);
    uint32_t avg8 = ADC1_SampleAverage(NUM_SAMPLES);
    results.v_8bit = ((float)avg8 / 255.0f) * VREF_PLUS;
    UART2_PrintFloat(" [ 8-bit] Voltage : ", results.v_8bit);

    /* 4. 6-bit Mode (Max = 63) */
    ADC1_SetResolution(0x3);
    uint32_t avg6 = ADC1_SampleAverage(NUM_SAMPLES);
    results.v_6bit = ((float)avg6 / 63.0f) * VREF_PLUS;
    UART2_PrintFloat(" [ 6-bit] Voltage : ", results.v_6bit);

    /* Restore default 12-bit resolution */
    ADC1_SetResolution(0x0);

    /* Erase Sector 7 and persist new results */
    UART2_SendString("\r\nPersisting results to Sector 7...\r\n");
    Flash_EraseSector(7);

    for (uint32_t i = 0; i < sizeof(TestResults_t); i += 4)
    {
        uint32_t w;
        memcpy(&w, ((uint8_t *)&results) + i, 4);
        Flash_WriteWord(SEC7_BASE + i, w);
    }

    UART2_SendString("SUCCESS: Sector 7 flash update complete!\r\n");
    UART2_SendString("Press any key to run the test suite again...\r\n");
}

/* ============================================================================
 * MAIN ENTRY POINT
 * ============================================================================ */
int main(void)
{
    /* Initialize Board Peripherals */
    UART2_Init();
    ADC1_Init();

    /* UNCOMMENT ONCE FOR FIRST TIME PROVISIONING: */
    // System_ProvisionStudentIdentity();

    /* Step 1 & 2: Milestone E System Startup Telemetry */
    Boot_DisplayStudentIdentity();
    Boot_DisplayPreviousResults();

    UART2_SendString("\r\n[SYSTEM READY] Send any byte over UART to trigger test execution...\r\n");

    /* Main Execution Loop */
    while (1)
    {
        /* Milestone D: Auto-trigger execution on UART input */
        if (UART2_IsRxReady())
        {
            (void)UART2_ReadChar(); /* Flush received byte */

            /* Debounce delay loop to absorb key bounce or fast serial bursts */
            for (volatile uint32_t d = 0; d < 2000000; d++);
            while (UART2_IsRxReady()) { (void)UART2_ReadChar(); }

            /* Execute multi-resolution test sequence */
            Run_MultiResolutionTestSuite();
        }
    }
}