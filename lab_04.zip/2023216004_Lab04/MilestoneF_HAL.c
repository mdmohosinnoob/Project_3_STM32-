#include "main.h"
#include <stdio.h>
#include <string.h>

/* ============================================================================
 * FLASH MEMORY MAP & CONSTANTS
 * ============================================================================ */
#define SEC6_BASE           0x08040000U  /* Sector 6: Student Identity */
#define SEC7_BASE           0x08060000U  /* Sector 7: Test Results */

#define ID_MARKER           0xB1010001U  /* Identity Marker */
#define TEST_MARKER         0xCAFEBABEU  /* Test Results Marker */

#define VREF_PLUS           3.3f         /* Analog Reference Voltage (V) */
#define NUM_SAMPLES         16           /* Sample Count per Resolution */

/* ============================================================================
 * DATA STRUCTURES
 * ============================================================================ */
typedef struct {
    uint32_t marker;
    char registration[16];
    char roll[12];
    char name[32];
} StudentInfo_t;

typedef struct {
    uint32_t marker;
    float v_12bit;
    float v_10bit;
    float v_8bit;
    float v_6bit;
} TestResults_t;

/* ============================================================================
 * PERIPHERAL HANDLES & PROTOTYPES
 * ============================================================================ */
ADC_HandleTypeDef hadc1;
UART_HandleTypeDef huart2;

void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_ADC1_Init(void);
static void MX_USART2_UART_Init(void);

/* ============================================================================
 * HAL FLASH UTILITY FUNCTIONS
 * ============================================================================ */
static void Flash_EraseSector_HAL(uint32_t sector)
{
    FLASH_EraseInitTypeDef eraseInit;
    uint32_t sectorError;

    HAL_FLASH_Unlock();
    eraseInit.TypeErase    = FLASH_TYPEERASE_SECTORS;
    eraseInit.Sector       = sector;
    eraseInit.NbSectors    = 1;
    eraseInit.VoltageRange = FLASH_VOLTAGE_RANGE_3;

    HAL_FLASHEx_Erase(&eraseInit, &sectorError);
    HAL_FLASH_Lock();
}

static void Flash_WriteWord_HAL(uint32_t addr, uint32_t data)
{
    HAL_FLASH_Unlock();
    HAL_FLASH_Program(FLASH_TYPEPROGRAM_WORD, addr, (uint64_t)data);
    HAL_FLASH_Lock();
}

static uint32_t Flash_ReadWord_HAL(uint32_t addr)
{
    return *(volatile uint32_t *)addr;
}

/* ============================================================================
 * MILESTONE C: IDENTITY MANAGEMENT (HAL)
 * ============================================================================ */

/**
 * @brief One-time provisioning routine to flash student identity to Sector 6.
 *        Uncomment in main() ONCE to run, then re-comment to protect Sector 6.
 */
void System_ProvisionStudentIdentity_HAL(void)
{
    StudentInfo_t s;
    s.marker = ID_MARKER;

    memset(s.registration, 0, sizeof(s.registration));
    memset(s.roll, 0, sizeof(s.roll));
    memset(s.name, 0, sizeof(s.name));

    strcpy(s.registration, "REG123456");
    strcpy(s.roll, "42");
    strcpy(s.name, "Shahriar Islam");

    Flash_EraseSector_HAL(FLASH_SECTOR_6);

    for (uint32_t i = 0; i < sizeof(StudentInfo_t); i += 4)
    {
        uint32_t word;
        memcpy(&word, ((uint8_t *)&s) + i, 4);
        Flash_WriteWord_HAL(SEC6_BASE + i, word);
    }
}

static void Boot_DisplayStudentIdentity_HAL(void)
{
    if (Flash_ReadWord_HAL(SEC6_BASE) != ID_MARKER)
    {
        printf("\r\n========================================\r\n");
        printf(" Student Identity: NOT PROVISIONED      \r\n");
        printf("========================================\r\n");
        return;
    }

    StudentInfo_t s;
    for (uint32_t i = 0; i < sizeof(StudentInfo_t); i += 4)
    {
        uint32_t word = Flash_ReadWord_HAL(SEC6_BASE + i);
        memcpy(((uint8_t *)&s) + i, &word, 4);
    }

    printf("\r\n========================================\r\n");
    printf("       STUDENT IDENTITY (Sector 6)      \r\n");
    printf("========================================\r\n");
    printf(" Registration : %s\r\n", s.registration);
    printf(" Roll Number  : %s\r\n", s.roll);
    printf(" Name         : %s\r\n", s.name);
}

/* ============================================================================
 * MILESTONE E: PREVIOUS TEST DISPLAY (HAL)
 * ============================================================================ */
static void Boot_DisplayPreviousResults_HAL(void)
{
    if (Flash_ReadWord_HAL(SEC7_BASE) != TEST_MARKER)
    {
        printf("\r\n========================================\r\n");
        printf(" Test Results: NO PREVIOUS DATA FOUND   \r\n");
        printf("========================================\r\n");
        return;
    }

    TestResults_t r;
    for (uint32_t i = 0; i < sizeof(TestResults_t); i += 4)
    {
        uint32_t word = Flash_ReadWord_HAL(SEC7_BASE + i);
        memcpy(((uint8_t *)&r) + i, &word, 4);
    }

    printf("\r\n========================================\r\n");
    printf("     PREVIOUS TEST RESULTS (Sector 7)   \r\n");
    printf("========================================\r\n");
    printf(" 12-bit Resolution : %.3f V\r\n", r.v_12bit);
    printf(" 10-bit Resolution : %.3f V\r\n", r.v_10bit);
    printf("  8-bit Resolution : %.3f V\r\n", r.v_8bit);
    printf("  6-bit Resolution : %.3f V\r\n", r.v_6bit);
}

/* ============================================================================
 * MILESTONE D: MULTI-RESOLUTION ADC TEST SUITE (HAL)
 * ============================================================================ */
static void HAL_ADC_ReconfigResolution(uint32_t resolution)
{
    hadc1.Init.Resolution = resolution;
    HAL_ADC_Init(&hadc1);
}

static uint32_t HAL_ADC_SampleAverage(uint8_t n_samples)
{
    uint32_t sum = 0;
    for (uint8_t i = 0; i < n_samples; i++)
    {
        HAL_ADC_Start(&hadc1);
        if (HAL_ADC_PollForConversion(&hadc1, 10) == HAL_OK)
        {
            sum += HAL_ADC_GetValue(&hadc1);
        }
        HAL_ADC_Stop(&hadc1);
        HAL_Delay(5);
    }
    return sum / n_samples;
}

static void Run_MultiResolutionTestSuite_HAL(void)
{
    TestResults_t results;
    results.marker = TEST_MARKER;

    printf("\r\n========================================\r\n");
    printf("   RUNNING MULTI-RESOLUTION TEST SUITE  \r\n");
    printf("========================================\r\n");

    /* 1. 12-bit Mode (Max = 4095) */
    HAL_ADC_ReconfigResolution(ADC_RESOLUTION_12B);
    uint32_t avg12 = HAL_ADC_SampleAverage(NUM_SAMPLES);
    results.v_12bit = ((float)avg12 / 4095.0f) * VREF_PLUS;
    printf(" [12-bit] Voltage : %.3f V\r\n", results.v_12bit);

    /* 2. 10-bit Mode (Max = 1023) */
    HAL_ADC_ReconfigResolution(ADC_RESOLUTION_10B);
    uint32_t avg10 = HAL_ADC_SampleAverage(NUM_SAMPLES);
    results.v_10bit = ((float)avg10 / 1023.0f) * VREF_PLUS;
    printf(" [10-bit] Voltage : %.3f V\r\n", results.v_10bit);

    /* 3. 8-bit Mode (Max = 255) */
    HAL_ADC_ReconfigResolution(ADC_RESOLUTION_8B);
    uint32_t avg8 = HAL_ADC_SampleAverage(NUM_SAMPLES);
    results.v_8bit = ((float)avg8 / 255.0f) * VREF_PLUS;
    printf(" [ 8-bit] Voltage : %.3f V\r\n", results.v_8bit);

    /* 4. 6-bit Mode (Max = 63) */
    HAL_ADC_ReconfigResolution(ADC_RESOLUTION_6B);
    uint32_t avg6 = HAL_ADC_SampleAverage(NUM_SAMPLES);
    results.v_6bit = ((float)avg6 / 63.0f) * VREF_PLUS;
    printf(" [ 6-bit] Voltage : %.3f V\r\n", results.v_6bit);

    /* Restore default resolution */
    HAL_ADC_ReconfigResolution(ADC_RESOLUTION_12B);

    /* Erase Sector 7 and write updated results */
    printf("\r\nPersisting results to Sector 7...\r\n");
    Flash_EraseSector_HAL(FLASH_SECTOR_7);

    for (uint32_t i = 0; i < sizeof(TestResults_t); i += 4)
    {
        uint32_t word;
        memcpy(&word, ((uint8_t *)&results) + i, 4);
        Flash_WriteWord_HAL(SEC7_BASE + i, word);
    }

    printf("SUCCESS: Sector 7 flash update complete!\r\n");
    printf("Press any key to run the test suite again...\r\n");
}

/* ============================================================================
 * MAIN ENTRY POINT (HAL)
 * ============================================================================ */
int main(void)
{
    uint8_t rx_byte;

    HAL_Init();
    SystemClock_Config();

    MX_GPIO_Init();
    MX_USART2_UART_Init();
    MX_ADC1_Init();

    /* UNCOMMENT ONCE FOR FIRST TIME PROVISIONING: */
    // System_ProvisionStudentIdentity_HAL();

    /* Milestone E Startup Telemetry */
    Boot_DisplayStudentIdentity_HAL();
    Boot_DisplayPreviousResults_HAL();

    printf("\r\n[SYSTEM READY] Send any byte over UART to trigger test execution...\r\n");

    while (1)
    {
        /* Polling check on UART RX with non-blocking 10ms timeout */
        if (HAL_UART_Receive(&huart2, &rx_byte, 1, 10) == HAL_OK)
        {
            HAL_Delay(200); /* Software debounce delay for rapid inputs */
            __HAL_UART_FLUSH_DRREGISTER(&huart2); /* Flush remaining bytes */

            Run_MultiResolutionTestSuite_HAL();
        }
    }
}

/* ============================================================================
 * LOW-LEVEL HAL INITIALIZATION & PRINTF REDIRECTION
 * ============================================================================ */

/* Retarget printf output to USART2 */
int _write(int file, char *ptr, int len)
{
    HAL_UART_Transmit(&huart2, (uint8_t *)ptr, len, HAL_MAX_DELAY);
    return len;
}

static void MX_ADC1_Init(void)
{
    ADC_ChannelConfTypeDef sConfig = {0};

    hadc1.Instance                   = ADC1;
    hadc1.Init.ClockPrescaler        = ADC_CLOCK_SYNC_PCLK_DIV4;
    hadc1.Init.Resolution            = ADC_RESOLUTION_12B;
    hadc1.Init.ScanConvMode          = DISABLE;
    hadc1.Init.ContinuousConvMode    = DISABLE;
    hadc1.Init.DiscontinuousConvMode = DISABLE;
    hadc1.Init.ExternalTrigConvEdge  = ADC_EXTERNALTRIGCONVEDGE_NONE;
    hadc1.Init.ExternalTrigConv      = ADC_SOFTWARE_START;
    hadc1.Init.DataAlign             = ADC_DATAALIGN_RIGHT;
    hadc1.Init.NbrOfConversion       = 1;
    hadc1.Init.DMAContinuousRequests = DISABLE;
    hadc1.Init.EOCSelection          = ADC_EOC_SINGLE_CONV;
    HAL_ADC_Init(&hadc1);

    sConfig.Channel      = ADC_CHANNEL_0;
    sConfig.Rank         = 1;
    sConfig.SamplingTime = ADC_SAMPLETIME_56CYCLES;
    HAL_ADC_ConfigChannel(&hadc1, &sConfig);
}

static void MX_USART2_UART_Init(void)
{
    huart2.Instance          = USART2;
    huart2.Init.BaudRate     = 115200;
    huart2.Init.WordLength   = UART_WORDLENGTH_8B;
    huart2.Init.StopBits     = UART_STOPBITS_1;
    huart2.Init.Parity       = UART_PARITY_NONE;
    huart2.Init.Mode         = UART_MODE_TX_RX;
    huart2.Init.HwFlowCtl    = UART_HWCONTROL_NONE;
    huart2.Init.OverSampling = UART_OVERSAMPLING_16;
    HAL_UART_Init(&huart2);
}

static void MX_GPIO_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};

    __HAL_RCC_GPIOA_CLK_ENABLE();

    /* PA0 in Analog Mode for ADC1 */
    GPIO_InitStruct.Pin  = GPIO_PIN_0;
    GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
}

void SystemClock_Config(void)
{
    /* Clock configuration using internal HSI default */
}

void Error_Handler(void)
{
    __disable_irq();
    while (1) {}
}